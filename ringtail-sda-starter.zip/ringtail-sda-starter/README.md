# Ringtail SDA filtering starter

This handoff contains the pure Rust Structured Data Algebra (SDA) evaluator
from Residiuum, plus the specifications and reference lowering code useful for
adapting it into an in-memory telemetry filter for Ringtail.

The included `sda` crate is standalone: it has no Residiuum storage, networking,
SDK, or workspace dependencies. Its evaluation model is pure input -> output.

## Recommended starting point

Compile each registered filter once, then evaluate the compiled program for
each incoming JSON event:

```rust
use residiuum_sda::Program;
use serde_json::{json, Value};

let filter = Program::parse(
    r#"(getPath(input, Seq["severity"]) = Some("error"))
       and (getPath(input, Seq["service"]) = Some("payments"))"#,
)?;

let event = json!({"severity": "error", "service": "payments"});
let matched = matches!(filter.run_json("input", event)?, Value::Bool(true));
# Ok::<(), Box<dyn std::error::Error>>(())
```

Run the included demonstration with:

```sh
cd sda
cargo run --example ringtail_filter
```

Run the complete evaluator test suite with:

```sh
cd sda
cargo test
```

## Suggested Ringtail boundary

Wrap `Program` behind a small application-owned API such as:

```text
CompiledFilter::compile(source, limits)
CompiledFilter::matches(event) -> Match | NoMatch | EvaluationError
```

Important production work before accepting untrusted filter text:

- impose source-size, token, AST-depth and literal-size limits;
- add an evaluation work/fuel budget or deadline;
- compile once and cache by canonical source/hash;
- define whether evaluation errors quarantine the filter or the event;
- avoid converting or cloning the same event once per subscriber;
- benchmark one event against many registered filters, not only one filter;
- begin with a restricted Boolean predicate profile rather than all SDA/ENR1.

The current evaluator does not provide a per-evaluation fuel counter. Do not
expose unrestricted programs to untrusted tenants until that guard exists.

## Contents

- `sda/` — standalone, buildable SDA+ENR1 Rust crate, tests and examples.
- `docs/SDA_SPEC.md` — normative SDA language semantics.
- `docs/SDA_PROFILE.md` — Residiuum's accepted SDA profile.
- `docs/RESIDIUUM_PREDICATE_SPEC.md` — narrower predicate semantics suitable
  for a predictable telemetry-filter surface.
- `docs/ENR1.md` — enrichment extensions implemented by the same parser. Ringtail
  probably does not need these for its first stateless filter implementation.
- `reference/residiuum-predicate.rs` — Residiuum predicate AST/evaluator.
- `reference/predicate-to-sda-kernel.rs` — reference predicate-to-SDA lowering.
  It is intentionally reference material and still imports Residiuum SDK types;
  copy/adapt the relevant design rather than expecting this file to compile here.
- `reference/residiuum-sda-original-Cargo.toml` — original monorepo manifest.

## What is deliberately not included

The Residiuum Query VM, collection host, pagination, index-selection and storage
layers are omitted. They are collection-oriented and are unnecessary for a
first stateless `event -> Boolean` Ringtail filter. If Ringtail later needs
projection, routing, ordering or windowed queries, those pieces can be assessed
separately.

## Licence and provenance

The SDA crate is MIT licensed. Preserve `LICENSE-MIT` and its copyright notice
in derived distributions. The reference predicate/kernel files came from the
Residiuum SDK; confirm their licensing and intended reuse before incorporating
them directly into a separately distributed project.

Snapshot prepared from Residiuum 0.2.2 on 2026-08-08.
