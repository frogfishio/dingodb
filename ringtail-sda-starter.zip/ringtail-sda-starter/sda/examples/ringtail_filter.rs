use residiuum_sda::Program;
use serde_json::{json, Value};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Compile once when a subscription/filter is registered.
    let filter = Program::parse(
        r#"(getPath(input, Seq["severity"]) = Some("error"))
           and (getPath(input, Seq["service"]) = Some("payments"))"#,
    )?;

    let events = [
        json!({"severity": "info", "service": "payments", "message": "started"}),
        json!({"severity": "error", "service": "search", "message": "timeout"}),
        json!({"severity": "error", "service": "payments", "message": "declined"}),
    ];

    // Reuse the parsed program for every incoming event.
    for event in events {
        let outcome = filter.run_json("input", event.clone())?;
        let matched = matches!(outcome, Value::Bool(true));
        if matched {
            println!("MATCH {event}");
        }
    }

    Ok(())
}
